﻿(function (angular, undefined) {
    'use strict';

    var module = angular.module('tasklist.tasks', [
        'ngRoute',
        'tasklist.common',
    ]);

    module.config(['$routeProvider', function ($routeProvider) {
        $routeProvider
            .when('/tasks', {
                controller: 'TasksController',
                templateUrl: 'WebApp/tasklist/task/tasklist.html'
            })
            .otherwise({
                redirectTo: '/tasks'
            });
    }]);

    module.directive('onEsc', onEscapeKeyPress);
    module.directive('onEnter', onEnterKeyPress);
    module.directive('inlineEdit', inlineEdit);
    
    function onEscapeKeyPress() {
        return {
            link: function ($scope, elm, attr) {
                elm.bind('keydown', function (e) {
                    alert('12');
                    if (e.keyCode === 27) {
                        $scope.$apply(attr.onEsc);
                    }
                });
            }
        };
    }

    function onEnterKeyPress() {
        return {
            link: function ($scope, elm, attr) {
                elm.bind('keypress', function (e) {
                    alert('11');
                    if (e.keyCode === 13) {
                        $scope.$apply(attr.onEnter);
                    }
                });
            }
        };
    }

    function inlineEdit($timeout) {
        return {
            scope: {
                model: '=inlineEdit',
                handleSave: '&onSave',
                handleCancel: '&onCancel'
            },
            link: function ($scope, elm, attr) {
                var previousValue;

                $scope.edit = function () {
                    alert('1');
                    $scope.editMode = true;
                    previousValue = $scope.model;

                    $timeout(function () { elm.find('input')[0].focus; }, 0, false);
                };

                $scope.save = function () {
                    $scope.editModel = false;
                    $scope.handleSave({ value: $scope.model });
                };

                $scope.cancel = function () {
                    $scope.editMode = false;
                    $scope.model = previousValue;
                    $scope.handleCancel({ value: $scope.model });
                };
            }
        };
    }

    module.controller("TasksController", ['$scope', '$common', '$user', '$routeParams', 'SignalR', tasksController]);

    function tasksController($scope, $common, $user, $routeParams, SignalR) {
        var Api = $common.Api;
        var Error = $common.Error;
        var $events = $common.$events;
        var $config = $common.$config;
        $scope.baseUrl = $config.API_ENDPOINT;
        $scope.defaultPath = $config.RESOURCE_HOST;

        $scope.selectedTaskCount = 0;
        $scope.isDefaultProject = false;

        debugger;
        $scope.projectID = 0;
        if ($routeParams.project != undefined) {
            $scope.projectID = parseInt($routeParams.project);
        }
        Api.Task.getTasks({ userId: $user.Id, projectID: $scope.projectID }, function (data) {
            debugger;
            $scope.projectName = data.ProjectName;
            $scope.tasks = data.Tasks;
            $scope.isDefaultProject = data.IsDefaultProject;
        }, function () {
        });

        $scope.saveTask = function (value) {
            alert('saving task' + value);
        };

        $scope.cancelTask = function (value) {
            alert('cancelling task' + value);
        };
    }

}(angular));